#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5
#define NUM_SAUCE_BOWLS 2

int forks[NUM_PHILOSOPHERS];
int sauce_bowls[NUM_SAUCE_BOWLS];

void *TABLE(void *arg) {
  int id = *((int*)arg);
  int leftfork = (id+NUM_PHILOSOPHERS)%NUM_PHILOSOPHERS;
  int rightfork = (id + 1) % NUM_PHILOSOPHERS;
  int sauce_bowl=id%NUM_SAUCE_BOWLS;

  for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
    printf("Philosopher %d is thinking\n", id);
    if (id % 2 == 0) {
      while (forks[leftfork] == 0 || forks[rightfork] == 0);
      forks[leftfork] = forks[rightfork] = 0;
    } else {
      while (forks[rightfork] == 0 || forks[leftfork] == 0);
      forks[rightfork] = forks[leftfork] = 0;
    }

    printf("Philosopher %d picks up fork %d\n", id, leftfork);
    sleep(1);
    printf("Philosopher %d picks up fork %d\n", id, rightfork);

    printf("Philosopher %d is eating with sauce bowl %d\n", id, sauce_bowl);
    sauce_bowls[sauce_bowl] = 1;

    forks[leftfork] = forks[rightfork] = 1;
    printf("Philosopher %d finished eating\n", id);
    sleep(1);
  }

  pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int ids[NUM_PHILOSOPHERS];
    int lim = 0;
    while( lim < NUM_PHILOSOPHERS)
    {   ids[lim] = lim;
        forks[lim] = 1;
        sauce_bowls[lim] = 1;
        lim++;
    }
    int ele=0;
    while(ele < NUM_PHILOSOPHERS) {
    if (pthread_create(&philosophers[ele], NULL, TABLE, &ids[ele])) {
      return 1;
    }
    ele++;
    }
    int opa = 0;
    while(opa < NUM_PHILOSOPHERS)
    {
    if (pthread_join(philosophers[opa], NULL)) {
      return 2;
    }
    opa++;
    }

  return 0;
}
