#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>

#define NUM_PHILOSOPHERS 5

sem_t forks[NUM_PHILOSOPHERS];

void *TABLE(void *arg) {
  int id = *((int*)arg);
  int leftfork = (id+NUM_PHILOSOPHERS)%NUM_PHILOSOPHERS;
  int rightfork = (id + 1) % NUM_PHILOSOPHERS;

  for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
    printf("Philosopher %d is thinking\n", id);
    if (id % 2 == 0) {
      sem_wait(&forks[leftfork]);
      sem_wait(&forks[rightfork]);
    } else {
      sem_wait(&forks[rightfork]);
      sem_wait(&forks[leftfork]);
    }

    printf("Philosopher %d picks up fork %d\n", id, leftfork);
    printf("Philosopher %d picks up fork %d\n", id, rightfork);
    sleep(1);
    printf("Philosopher %d is eating\n", id);
    printf("Philosopher %d finished eating\n", id);

    sem_post(&forks[leftfork]);
    sem_post(&forks[rightfork]);

    sleep(1);
  }

  pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int ids[NUM_PHILOSOPHERS];
    int lim = 0;
    while( lim < NUM_PHILOSOPHERS)
    {   ids[lim] = lim;
        sem_init(&forks[lim],0,1);
        lim++;
    }
    int ele=0;
    while(ele < NUM_PHILOSOPHERS) {
    if (pthread_create(&philosophers[ele], NULL, TABLE, &ids[ele])) {
      return 1;
    }
    ele++;
    }
    int opa = 0;
    while(opa < NUM_PHILOSOPHERS)
    {
    if (pthread_join(philosophers[opa], NULL)) {
      return 2;
    }
    opa++;
    }

  return 0;
}
