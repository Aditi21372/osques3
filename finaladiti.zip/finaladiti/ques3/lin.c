.#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/syscalls.h>
#include <linux/unistd.h>
#include <asm/syscall.h>
#include <linux/uidgid.h>
#include <linux/pid.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Aditi");

#define __NR_get_process_info 293

asmlinkage long sys_print_process_info(pid_t pid, uid_t uid)
{
    struct task_struct *task;

    task = find_task_by_vpid(pid);
    if (!task)
        return -ESRCH;

    if (!uid_valid(uid) || !uid_eq(uid, task->cred->uid))
        return -EINVAL;

    printk("pid: %d\n", pid_vnr(task_pid(task)));
    printk("user_id: %d\n", from_kuid_munged(current_user_ns(), task->cred->uid));
    printk("pgid: %d\n", task_pgrp_vnr(task));
    printk("command path: %s\n", get_task_comm(task));
    return 0;
}

static const char *syscall_names[] = {
    "print_process_info",
};

static unsigned long *sys_call_table[NR_syscalls + 1];

static asmlinkage long (*original_syscalls[])(const struct pt_regs *) = {
    [__NR_get_process_info] = (void *)sys_print_process_info,
};

static int __init my_module_init(void)
{
    int i=0;
    while(i < NR_syscalls) {
    sys_call_table[i] = (unsigned long *)sys_call_table[i];
    original_syscalls[i] = (void *)sys_call_table[i];
     i++;
}
for (i = 0; i < NR_syscalls; i++) {
    if (syscall_names[i])
        sys_call_table[__NR_get_process_info] = (unsigned long *)original_syscalls[i];
}

return 0;
}

static void __exit my_module_exit(void)
{
int i=0;
while(i < NR_syscalls) {
    if (syscall_names[i])
        sys_call_table[__NR_get_process_info] = (unsigned long *)original_syscalls[i];
    i++;
}
}

module_init(my_module_init);
module_exit(my_module_exit);