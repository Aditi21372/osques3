#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define STR_LEN 5
#define NUM_STRINGS 50
#define GROUP_SIZE 5

int getFIFO(int arg, int varg){
    if (mkfifo("/tmp/myfifo", 0666) < 0) {
    printf("Error creating FIFO");
    return arg;
  }
  int file = open("/tmp/myfifo", O_WRONLY);
  if (file < varg) {
    printf("Error opening FIFO for writing");
    return arg;
  }
  return file;
}
int main(int argc, char* argv[]) {
  srand(time(NULL));
  char strings[NUM_STRINGS][STR_LEN+1];
  for (int i = 0; i < NUM_STRINGS; i++) {
    for (int j = 0; j < STR_LEN; j++) {
      strings[i][j] = 'a' + rand() % 26;
    }
    strings[i][STR_LEN] = '\0';
  }
  int arg[2]={1,0};
  int file=getFIFO(arg[0], arg[1]);
  int highest_id;
  for (int i = 0; i < NUM_STRINGS; i += GROUP_SIZE) {
    highest_id = i; 
    write(file, &highest_id, sizeof(int)); 
    write(file, &strings[i], GROUP_SIZE * (STR_LEN+1) * sizeof(char)); 
    read(file, &highest_id, sizeof(int)); 
    printf("Highest index received: %d\n", highest_id);
  }
  close(file);
  return 0;
}