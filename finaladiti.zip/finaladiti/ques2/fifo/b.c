#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define STR_LEN 5
#define GROUP_SIZE 5
char strings[GROUP_SIZE][STR_LEN+1];

void read_strings(int file) {
  int idx;
  while (read(file, &idx, sizeof(int)) > 0) {
    read(file, strings, GROUP_SIZE * (STR_LEN+1) * sizeof(char));
    for (int i = 0; i < GROUP_SIZE; i++) {
      printf("String %d: %s\n", idx+i, strings[i]);
    }
    idx += GROUP_SIZE - 1;
    write(file, &idx, sizeof(int)); 
  }
}

int main() {
  int file = open("fifkoko", O_RDONLY);
  read_strings(file);
  close(file);
  return 0;
}
