#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define Maxlength 5
#define Num 50
#define Groupsize 5

char buf[Num][Maxlength + 1];

void getrandom(){
    for (int i = 0; i < Num; i++) {
        for (int j = 0; j < Maxlength; j++) {
            buf[i][j] = 'A' + rand() % 26;
        }
        buf[i][Maxlength] = '\0';
    }
}

void server(int fd){
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, "socket_file", sizeof(addr.sun_path) - 1);

    if (connect(fd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) < 0) {
        printf("Error in connecting");
        exit(1);
    }
}
int main() {
    getrandom();
    int sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sockfd < 0) {
        printf("Error creating socket");
    }
    server(sockfd);
    for (int i = 0; i < Num; i += Groupsize) {
        for (int j = 0; j < Groupsize; j++) {

            if (write(sockfd, &i, sizeof(int)) < 0) {
                printf("Error sending string ID");
                exit(1);
            }

            if (write(sockfd, buf[i + j], Maxlength + 1) < 0) {
                printf("Error sending string");
                exit(1);
            }
        }
        int highest_id;
        if (read(sockfd, &highest_id, sizeof(int)) < 0) {
            printf("Error receiving highest ID");
            exit(1);
        }
    }

    close(sockfd);

    return 0;
}