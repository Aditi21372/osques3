#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define maxlength 5
#define Num 50
#define Groupsize 5

int server(int sockfd){
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, "socket_file", sizeof(addr.sun_path) - 1);

    if (bind(sockfd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) < 0) {
        printf("Error binding socket");
        exit(1);
    }

    if (listen(sockfd, 5) < 0) {
        printf("Error listening for connections");
        exit(1);
    }

    int connfd = accept(sockfd, NULL, NULL);
    if (connfd < 0) {
        printf("Error accepting connection from P1");
        exit(1);
    }
    return connfd;
}
int main(int argc, char *argv[]) {

    int sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sockfd < 0) {
        printf("Error creating socket");
        exit(1);
    }
    int connfd=server(sockfd);

    for (int i = 0; i < Num; i += Groupsize) {
        int highest_id = -1;
        for (int j = 0; j < Groupsize; j++) {
            int string_id;
            char string[maxlength + 1];

            if (read(connfd, &string_id, sizeof(int)) < 0) {
                printf("Error receiving string ID from P1");
                exit(1);
            }

            if (read(connfd, string, maxlength + 1) < 0) {
                printf("Error receiving string from P1");
                exit(1);
            }

            printf("Received string :%s\n", string);

            if (string_id > highest_id) {
                highest_id = string_id;
            }
            
        }

        if (write(connfd, &highest_id, sizeof(int)) < 0) {
            printf("Error sending highest ID to P1");
            exit(1);
        }

    }

    close(connfd);
    close(sockfd);

    return 0;
}
